const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

const pool = mysql.createPool({
  host:     process.env.DB_HOST     || 'localhost',
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

pool.get = async (sql, params = []) => {
  const [rows] = await pool.query(sql, params);
  return rows[0] || null;
};
pool.all = async (sql, params = []) => {
  const [rows] = await pool.query(sql, params);
  return rows;
};
pool.run = async (sql, params = []) => {
  const [result] = await pool.query(sql, params);
  return { insertId: result.insertId, affectedRows: result.affectedRows };
};

async function initDB() {
  const conn = await pool.getConnection();
  try {
    await conn.query(`
      CREATE TABLE IF NOT EXISTS amsam_users (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        name          VARCHAR(255) NOT NULL,
        college_id    VARCHAR(100) UNIQUE NOT NULL,
        email         VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        photo_path    VARCHAR(500) DEFAULT NULL,
        role          ENUM('super_admin','sub_admin','student','guest') NOT NULL DEFAULT 'student',
        organization  VARCHAR(255) DEFAULT NULL,
        batch         VARCHAR(50)  DEFAULT NULL,
        department    VARCHAR(100) DEFAULT NULL,
        phone         VARCHAR(20)  DEFAULT NULL,
        is_paid       TINYINT(1)   NOT NULL DEFAULT 0,
        paid_at       DATETIME     DEFAULT NULL,
        created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
      )
    `);
    await conn.query(`
      CREATE TABLE IF NOT EXISTS amsam_events (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        title       VARCHAR(255) NOT NULL,
        description TEXT,
        venue       VARCHAR(255),
        event_date  VARCHAR(50),
        event_time  VARCHAR(50),
        fee         INT DEFAULT 0,
        created_by  INT,
        created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES amsam_users(id) ON DELETE SET NULL
      )
    `);
    await conn.query(`
      CREATE TABLE IF NOT EXISTS amsam_documents (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        title       VARCHAR(255) NOT NULL,
        description TEXT,
        category    ENUM('MOM','MOU','Letters','Finance') NOT NULL,
        file_path   VARCHAR(500) NOT NULL,
        created_by  INT,
        created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES amsam_users(id) ON DELETE SET NULL
      )
    `);
    await conn.query(`
      CREATE TABLE IF NOT EXISTS amsam_registrations (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        user_id     INT,
        event_id    INT,
        qr_code     VARCHAR(255) UNIQUE NOT NULL,
        is_paid     TINYINT(1) NOT NULL DEFAULT 0,
        is_admitted TINYINT(1) NOT NULL DEFAULT 0,
        created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_reg (user_id, event_id),
        FOREIGN KEY (user_id)  REFERENCES amsam_users(id)  ON DELETE CASCADE,
        FOREIGN KEY (event_id) REFERENCES amsam_events(id) ON DELETE CASCADE
      )
    `);
    await conn.query(`
      CREATE TABLE IF NOT EXISTS amsam_payment_orders (
        order_id   VARCHAR(100) PRIMARY KEY,
        user_id    INT NOT NULL,
        event_id   INT NOT NULL,
        status     VARCHAR(50) DEFAULT 'created',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Migrate existing installations — add columns/values if missing
    try { await conn.query(`ALTER TABLE amsam_users MODIFY role ENUM('super_admin','sub_admin','student','guest') NOT NULL DEFAULT 'student'`); } catch(e) {}
    try { await conn.query(`ALTER TABLE amsam_users ADD COLUMN organization VARCHAR(255) DEFAULT NULL`); } catch(e) {}

    // Seed only if empty
    const [[{ c }]] = await conn.query('SELECT COUNT(*) as c FROM amsam_users');
    if (c === 0) {
      const h = (p) => bcrypt.hashSync(p, 10);
      const ins = `INSERT INTO amsam_users (name, college_id, email, password_hash, role, batch, department, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

      await conn.query(ins, ['Admin',            'ADMIN001',    'admin@amsam.in',                          h('Admin@123'),    'super_admin', '2018', 'Administration',  '9999999999']);
      await conn.query(ins, ['Dr. Meena Pillai', 'SADMIN001',   'subadmin@amsam.in',                       h('SubAdmin@123'), 'sub_admin',   '2019', 'General Medicine', '8888888888']);
      await conn.query(ins, ['Arjun Sharma',     'MBBS2023001', 'arjun.sharma@aiimsmangalagiri.edu.in',    h('Student@123'),  'student',     '2023', 'MBBS',             '7777777701']);
      await conn.query(ins, ['Priya Nair',       'MBBS2023002', 'priya.nair@aiimsmangalagiri.edu.in',      h('Student@123'),  'student',     '2023', 'MBBS',             '7777777702']);
      await conn.query(ins, ['Rahul Reddy',      'MBBS2022001', 'rahul.reddy@aiimsmangalagiri.edu.in',     h('Student@123'),  'student',     '2022', 'MBBS',             '7777777703']);
      await conn.query(ins, ['Sneha Thomas',     'MBBS2022002', 'sneha.thomas@aiimsmangalagiri.edu.in',    h('Student@123'),  'student',     '2022', 'MBBS',             '7777777704']);

      const [[admin]]   = await conn.query('SELECT id FROM amsam_users WHERE college_id = ?', ['ADMIN001']);
      const [[subadmin]] = await conn.query('SELECT id FROM amsam_users WHERE college_id = ?', ['SADMIN001']);

      const insE = `INSERT INTO amsam_events (title, description, venue, event_date, event_time, created_by) VALUES (?,?,?,?,?,?)`;
      await conn.query(insE, ['Annual Medical Symposium 2025', 'A grand symposium featuring lectures from renowned medical professionals across India.', 'Main Auditorium, AIIMS Mangalagiri', '2025-05-15', '09:00 AM', admin.id]);
      await conn.query(insE, ['Blood Donation Camp', 'AMSAM organizes its annual blood donation camp in collaboration with the hospital blood bank.', 'Ground Floor Lobby, AIIMS Mangalagiri', '2025-04-25', '10:00 AM', admin.id]);
      await conn.query(insE, ['CPR & BLS Training Workshop', 'Hands-on CPR and Basic Life Support training for all MBBS students.', 'Skills Lab, AIIMS Mangalagiri', '2025-05-05', '02:00 PM', subadmin.id]);

      console.log('✅ AMSAM database seeded with demo data.');
    }

    console.log('✅ AMSAM MySQL tables ready.');
  } finally {
    conn.release();
  }
}

module.exports = pool;
module.exports.initDB = initDB;
