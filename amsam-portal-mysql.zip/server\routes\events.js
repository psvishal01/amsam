const router = require('express').Router();
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');
const xss = require('xss');

// GET /api/events
router.get('/', authenticate, async (req, res) => {
  try {
    const events = await db.all(
      `SELECT e.*, u.name as created_by_name
       FROM events e LEFT JOIN users u ON e.created_by = u.id
       ORDER BY e.event_date DESC`
    );
    res.json(events);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/events/:id
router.get('/:id', authenticate, async (req, res) => {
  try {
    const event = await db.get('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    res.json(event);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/events
router.post('/', authenticate, requireAdmin, async (req, res) => {
  try {
    const { title, description, venue, event_date, event_time, fee } = req.body;
    if (!title) return res.status(400).json({ error: 'Title is required' });
    const result = await db.run(
      'INSERT INTO events (title, description, venue, event_date, event_time, fee, created_by) VALUES (?,?,?,?,?,?,?)',
      [xss(title), xss(description || ''), xss(venue || ''), xss(event_date || ''), xss(event_time || ''), fee || 0, req.user.id]
    );
    res.status(201).json({ message: 'Event created', id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT /api/events/:id
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const { title, description, venue, event_date, event_time, fee } = req.body;
    const ev = await db.get('SELECT * FROM events WHERE id = ?', [req.params.id]);
    if (!ev) return res.status(404).json({ error: 'Event not found' });
    await db.run(
      'UPDATE events SET title=?, description=?, venue=?, event_date=?, event_time=?, fee=? WHERE id=?',
      [
        xss(title || ev.title),
        xss(description ?? ev.description),
        xss(venue ?? ev.venue),
        xss(event_date ?? ev.event_date),
        xss(event_time ?? ev.event_time),
        fee ?? ev.fee,
        req.params.id
      ]
    );
    res.json({ message: 'Event updated' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/events/:id
router.delete('/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    await db.run('DELETE FROM events WHERE id = ?', [req.params.id]);
    res.json({ message: 'Event deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
